package com.bymarcin.concurrentmodificationfix;

import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.google.common.collect.Sets;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.*;


import net.minecraft.launchwrapper.IClassTransformer;
import net.minecraft.launchwrapper.LaunchClassLoader;

public class Transformer implements IClassTransformer, Opcodes {
	public static final boolean obfuscated;
    static {
        boolean obf = true;
        try {
            obf = ((LaunchClassLoader) Transformer.class.getClassLoader()).getClassBytes("net.minecraft.world.World") == null;
        } catch (IOException iox) {
        }
        obfuscated = obf;
    }
    
    private final String trackedEntitiesName = obfuscated?"field_72793_b":"trackedEntities";
    public static Set getCon(){
    	return Collections.newSetFromMap(new ConcurrentHashMap());
    }
    
	@Override
	public byte[] transform(String name, String transformedName, byte[] basicClass) {
		if ("net.minecraft.entity.EntityTracker".equals(transformedName)) {
			ClassNode cn = new ClassNode();
			new ClassReader(basicClass).accept(cn, 0);
			for (MethodNode m : cn.methods) {
				if (!"<init>".equals(m.name)) {
					continue;
				}
				System.out.println("OBF????:   " + obfuscated);
				AbstractInsnNode target = null;
				Iterator<AbstractInsnNode> iterator = m.instructions.iterator();
				while (iterator.hasNext() && target == null) {
					AbstractInsnNode ins = iterator.next();
					if (ins instanceof FieldInsnNode) {
						FieldInsnNode fins = (FieldInsnNode) ins;
						if (fins.name.equals(trackedEntitiesName)) {
							target = fins;
							System.out.println("Target FOUND!");
						}
					}
				}
				if (target != null) {
					m.instructions.remove(target.getPrevious().getPrevious().getPrevious());
					m.instructions.remove(target.getPrevious().getPrevious());
					m.instructions.remove(target.getPrevious());

					m.instructions.insertBefore(target, new MethodInsnNode(INVOKESTATIC, Type.getInternalName(getClass()), "getCon", "()Ljava/util/Set;"));
					m.instructions.insertBefore(target, new FieldInsnNode(PUTFIELD, "net/minecraft/entity/EntityTracker", trackedEntitiesName, Type.getType(Set.class).getDescriptor()));
					m.instructions.remove(target);
				}
			}
			ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
			cn.accept(cw);
		
			return cw.toByteArray();
		}
		return basicClass;
	}

}
