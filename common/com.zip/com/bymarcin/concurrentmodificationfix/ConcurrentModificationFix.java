package com.bymarcin.concurrentmodificationfix;

import java.util.Map;

import cpw.mods.fml.common.DummyModContainer;
import cpw.mods.fml.common.ModMetadata;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin.TransformerExclusions;

@TransformerExclusions({"com.bymarcin.concurrentmodificationfix"})
public class ConcurrentModificationFix extends DummyModContainer implements IFMLLoadingPlugin {
	
	private static final ModMetadata md = new ModMetadata();
	
	static{
		md.modId = "concurrentmodificationfix";
		md.name = "ConcurrentModificationFix";
	}
	
	public ConcurrentModificationFix() {
		super(md);
	}

	@Override
	public String[] getASMTransformerClass() {
		return new String[]{Transformer.class.getName()};
	}

	@Override
	public String getModContainerClass() {
		return getClass().getName();
	}

	@Override
	public String getSetupClass() {
		return null;
	}

	@Override
	public void injectData(Map<String, Object> data) {

	}

	@Override
	public String getAccessTransformerClass() {
		return null;
	}
}
